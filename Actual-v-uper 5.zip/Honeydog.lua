
local honeycrap
function iloveloading()
honeycrap = love.graphics.newImage("Ohman.png")
end
function iloveupdates()

end
function ilovedrawing()
love.graphics.draw(honeycrap)
end