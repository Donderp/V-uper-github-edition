local COR_rage = {}
local COR_rage.enemies = {}

function COR_rage:spawnEmemy(x,y)