belts = {}
local lg = love.graphics
